## Get Affiliates lives within 100km of Dublin


1) php artisan serve
2) put address in browser address bar  http://127.0.0.1:8000/affiliates_lives_within_distance_of_dublin
3) php artisan test for start unit test - test service method for calculate distance between two points and check it is under 100km
